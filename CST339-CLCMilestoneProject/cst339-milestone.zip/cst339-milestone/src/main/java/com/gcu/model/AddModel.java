package com.gcu.model;


public class AddModel {

    private String title;        
    private String caption;
    private String picture;
    

    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setCaption(String cap) {
        this.caption = cap;
    }
    
    public String getCaption() {
        return caption;
    }
    
    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}

